﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KR
{
    /// <summary>
    /// Логика взаимодействия для InsertPage.xaml
    /// </summary>
    public partial class InsertPage : Window
    {
        DBVTEntities _db = new DBVTEntities();
        public InsertPage()
        {
            InitializeComponent();
        }

        private void insertBtn_Click(object sender, RoutedEventArgs e)
        {
            V_T newVT = new V_T()
            {
                Name_ob = name.Text,
                Zav_number = zn.Text,
                Inv_number = inv.Text,
                Licenzia = Convert.ToBoolean(lic.Text),
                Otv_l = otv.Text,
                Otdel = otd.Text,
                Image = img.Text

            };
            _db.V_T.Add(newVT);
            _db.SaveChanges();
            MainWindow.datagrid.ItemsSource = _db.V_T.ToList();
            this.Hide();
        }
    }
}
