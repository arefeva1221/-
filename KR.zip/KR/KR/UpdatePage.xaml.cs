﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KR
{
    /// <summary>
    /// Логика взаимодействия для UpdatePage.xaml
    /// </summary>
    public partial class UpdatePage : Window
    {
        DBVTEntities _db = new DBVTEntities();
        int Id;

        public UpdatePage(int vtId)
        {
            InitializeComponent();
            Id = vtId;
        }

        private void updateBtn_Click(object sender, RoutedEventArgs e)
        {
            V_T updateVT = (from v in _db.V_T
                            where v.Id == Id
                            select v).Single();
            updateVT.Name_ob = name.Text;
            updateVT.Zav_number = zn.Text;
            updateVT.Inv_number = inv.Text;
            updateVT.Licenzia = Convert.ToBoolean(lic.Text);
            updateVT.Otv_l = otv.Text;
            updateVT.Otdel = otd.Text;
            updateVT.Image = img.Text;


            _db.SaveChanges();
            MainWindow.datagrid.ItemsSource = _db.V_T.ToList();
            this.Hide();
        }
    }
}
