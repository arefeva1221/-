﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KR
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        DBVTEntities _db = new DBVTEntities();
        public static DataGrid datagrid;
        public MainWindow()
        {
            InitializeComponent();
            Load();
        }

        private void Load()
        {
            myDataGrid.ItemsSource = _db.V_T.ToList();
            datagrid = myDataGrid;
        }

        private void insertBtn(object sender, RoutedEventArgs e)
        {
            InsertPage Ipage = new InsertPage();
            Ipage.ShowDialog();
        }

        private void updateBtn(object sender, RoutedEventArgs e)
        {
            int Id = (myDataGrid.SelectedItem as V_T).Id;
            UpdatePage Upage = new UpdatePage(Id);
            Upage.ShowDialog();
        }

        private void deleteBtn(object sender, RoutedEventArgs e)
        {
            int Id = (myDataGrid.SelectedItem as V_T).Id;
            var deleteVT = _db.V_T.Where(v => v.Id == Id).Single();
            _db.V_T.Remove(deleteVT);
            _db.SaveChanges();
            myDataGrid.ItemsSource = _db.V_T.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
